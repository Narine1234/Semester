package com.example.demo.Service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired; import org.springframework.stereotype.Service;

import com.example.demo.Entity.Club;
import com.example.demo.Entity.Member;
import com.example.demo.Repo.ClubRepository;

@Service
public class ClubService { @Autowired
private ClubRepository clubRepository;

public List<Club> getAllClubs() { return clubRepository.findAll();
}

// Other CRUD operations for clubs

public void enrollMember(Long clubId, Member member) {
Club club = clubRepository.findById(clubId).orElseThrow(() -> new RuntimeException("Club not found"));
member.setClub(club); club.getMembers().add(member); clubRepository.save(club);
}
}

