package com.example.demo.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired; import org.springframework.web.bind.annotation.GetMapping; import org.springframework.web.bind.annotation.PathVariable; import org.springframework.web.bind.annotation.PostMapping; import org.springframework.web.bind.annotation.RequestBody; import org.springframework.web.bind.annotation.RequestMapping; import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Club;
import com.example.demo.Entity.Member;
import com.example.demo.Service.ClubService; @RestController
@RequestMapping("/api/clubs") public class ClubController {
@Autowired
private ClubService clubService; @GetMapping
public List<Club> getAllClubs() { return clubService.getAllClubs();
}
@PostMapping("/{clubId}/enroll")
public void enrollMember(@PathVariable Long clubId, @RequestBody Member member) { clubService.enrollMember(clubId, member);
}
// Other CRUD endpoints for clubs
}

