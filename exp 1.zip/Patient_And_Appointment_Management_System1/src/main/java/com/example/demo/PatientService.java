package com.example.demo;


import org.springframework.beans.factory.annotation.Autowired; import org.springframework.stereotype.Service;
import java.util.List; @Service
public class PatientService { @Autowired
private PatientRepository patientRepository;

public Patient createPatient(Patient patient) { return patientRepository.save(patient);
}

public List<Patient> getAllPatients() { return patientRepository.findAll();
}

public Patient getPatientById(Long id) {
return patientRepository.findById(id).orElse(null);
}

public Patient updatePatient(Long id, Patient newPatientData) { Patient existingPatient = patientRepository.findById(id).orElse(null); if (existingPatient != null) {
existingPatient.setName(newPatientData.getName()); existingPatient.setDateOfBirth(newPatientData.getDateOfBirth()); existingPatient.setContactNumber(newPatientData.getContactNumber()); existingPatient.setIssue(newPatientData.getIssue());
return patientRepository.save(existingPatient);
}
return null;
}

public void deletePatient(Long id) { patientRepository.deleteById(id);
}
}