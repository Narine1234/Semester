package com.example.demo;
import org.springframework.beans.factory.annotation.Autowired; import org.springframework.stereotype.Service;
import java.util.List; @Service
public class DoctorService {
@Autowired
private DoctorRepository doctorRepository;

public Doctor createDoctor(Doctor doctor) { return doctorRepository.save(doctor);
}

public List<Doctor> getAllDoctors() { return doctorRepository.findAll();
}

public Doctor getDoctorById(Long id) {
return doctorRepository.findById(id).orElse(null);
}

public Doctor updateDoctor(Long id, Doctor newDoctorData) { Doctor existingDoctor = doctorRepository.findById(id).orElse(null); if (existingDoctor != null) {
existingDoctor.setName(newDoctorData.getName()); existingDoctor.setSpecialty(newDoctorData.getSpecialty()); return doctorRepository.save(existingDoctor);
}
return null;
}

public void deleteDoctor(Long id) { doctorRepository.deleteById(id);
}
}

