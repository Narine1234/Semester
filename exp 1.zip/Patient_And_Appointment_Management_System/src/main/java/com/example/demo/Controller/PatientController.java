package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired; import org.springframework.web.bind.annotation.*;

import com.example.demo.Entity.Patient;
import com.example.demo.Service.PatientService;

@RestController @RequestMapping("/patients") public class PatientController {
@Autowired
private PatientService patientService;

@PostMapping
public Patient createPatient(@RequestBody Patient patient) { return patientService.createPatient(patient);
}

@GetMapping
public List<Patient> getAllPatients() { return patientService.getAllPatients();
}

@GetMapping("/{id}")
public Patient getPatientById(@PathVariable Long id) { return patientService.getPatientById(id);
}

@PutMapping("/{id}")
public Patient updatePatient(@PathVariable Long id, @RequestBody Patient newPatientData) { return patientService.updatePatient(id, newPatientData);
}

@DeleteMapping("/{id}")
public void deletePatient(@PathVariable Long id) {
 
patientService.deletePatient(id);
}
}
