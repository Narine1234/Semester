package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired; import org.springframework.web.bind.annotation.*;

import com.example.demo.Entity.Doctor;
import com.example.demo.Service.DoctorService;

@RestController @RequestMapping("/doctors") public class DoctorController {
@Autowired
private DoctorService doctorService;

@PostMapping
public Doctor createDoctor(@RequestBody Doctor doctor) { return doctorService.createDoctor(doctor);
}

@GetMapping
public List<Doctor> getAllDoctors() { return doctorService.getAllDoctors();
}

@GetMapping("/{id}")
public Doctor getDoctorById(@PathVariable Long id) { return doctorService.getDoctorById(id);
}

@PutMapping("/{id}")
public Doctor updateDoctor(@PathVariable Long id, @RequestBody Doctor newDoctorData) { return doctorService.updateDoctor(id, newDoctorData);
}

@DeleteMapping("/{id}")
public void deleteDoctor(@PathVariable Long id) { doctorService.deleteDoctor(id);
}
}

