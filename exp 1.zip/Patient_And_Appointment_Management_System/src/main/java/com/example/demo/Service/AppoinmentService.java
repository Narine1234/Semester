package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired; import org.springframework.stereotype.Service;

import com.example.demo.Entity.Appointment;
import com.example.demo.Repo.AppointmentRepository;

import java.util.List; import java.util.Optional;

@Service
public class AppoinmentService { @Autowired
private AppointmentRepository appointmentRepository;

public Appointment scheduleAppointment(Appointment appointment) { return appointmentRepository.save(appointment);
}

public List<Appointment> getAllAppointments() { return appointmentRepository.findAll();
}

public Appointment getAppointmentById(Long id) {
Optional<Appointment> appointmentOptional = appointmentRepository.findById(id); return appointmentOptional.orElse(null);
}

public Appointment rescheduleAppointment(Long id, String newDate, String newTime) { Optional<Appointment> appointmentOptional = appointmentRepository.findById(id); if (appointmentOptional.isPresent()) {
Appointment existingAppointment = appointmentOptional.get(); existingAppointment.setDate(newDate); existingAppointment.setTime(newTime);
return appointmentRepository.save(existingAppointment);
}
return null; // Or throw an exception indicating appointment not found
}

public void cancelAppointment(Long id) { appointmentRepository.deleteById(id);
}
}
