package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired; import org.springframework.web.bind.annotation.*;

import com.example.demo.Entity.Appointment;
import com.example.demo.Service.AppoinmentService;

@RestController @RequestMapping("/appointments") public class AppointmentController {
@Autowired
private AppoinmentService appointmentService;
 
@PostMapping
public Appointment scheduleAppointment(@RequestBody Appointment appointment) { return appointmentService.scheduleAppointment(appointment);
}

@GetMapping
public List<Appointment> getAllAppointments() { return appointmentService.getAllAppointments();
}

@GetMapping("/{id}")
public Appointment getAppointmentById(@PathVariable Long id) { return appointmentService.getAppointmentById(id);
}

@PutMapping("/{id}/reschedule")
public Appointment rescheduleAppointment(@PathVariable Long id, @RequestParam String newDate, @RequestParam String newTime) {
return appointmentService.rescheduleAppointment(id, newDate, newTime);
}

@DeleteMapping("/{id}")
public void cancelAppointment(@PathVariable Long id) { appointmentService.cancelAppointment(id);
}
}
