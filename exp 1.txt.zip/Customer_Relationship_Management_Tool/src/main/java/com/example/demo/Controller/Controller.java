 package com.example.demo.Controller;

 import java.util.List;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.data.domain.Page;
 import org.springframework.http.HttpStatus;
 import org.springframework.http.ResponseEntity;
 import org.springframework.web.bind.annotation.*;
 import com.example.demo.Entity.Model;
 import com.example.demo.Service.serv;

 @RestController
 @RequestMapping("/customers")
 public class Controller {

     @Autowired
     private serv customerService;

     @PostMapping("/create")
     public ResponseEntity<Model> createCustomer(@RequestBody Model customer) {
         Model createdCustomer = customerService.createCustomer(customer);
         return new ResponseEntity<>(createdCustomer, HttpStatus.CREATED);
     }

     @GetMapping("/get")
     public ResponseEntity<List<Model>> getAllCustomers() {
         List<Model> customers = customerService.getAllCustomers();
         return new ResponseEntity<>(customers, HttpStatus.OK);
     }

     @GetMapping("/getWithPagination")
     public ResponseEntity<Page<Model>> getAllCustomersWithPagination(
             @RequestParam(defaultValue = "0") int page,
             @RequestParam(defaultValue = "10") int size) {
         Page<Model> customers = customerService.getAllCustomersWithPagination(page, size);
         return new ResponseEntity<>(customers, HttpStatus.OK);
     }

     @GetMapping("/getWithPaginationAndSorting")
     public ResponseEntity<Page<Model>> getAllCustomersWithPaginationAndSorting(
             @RequestParam(defaultValue = "0") int page,
             @RequestParam(defaultValue = "10") int size,
             @RequestParam(defaultValue = "id") String sortBy) {
         Page<Model> customers = customerService.getAllCustomersWithPaginationAndSorting(page, size, sortBy);
         return new ResponseEntity<>(customers, HttpStatus.OK);
     }

     @GetMapping("/{id}")
     public ResponseEntity<Model> getCustomerById(@PathVariable int id) {
         Model customer = customerService.getCustomerById(id);
         if (customer != null) {
             return new ResponseEntity<>(customer, HttpStatus.OK);
         } else {
             return new ResponseEntity<>(HttpStatus.NOT_FOUND);
         }
     }

     @PutMapping("/{id}")
     public ResponseEntity<Model> updateCustomer(@PathVariable int id, @RequestBody Model updatedCustomer) {
         Model customer = customerService.updateCustomer(id, updatedCustomer);
         if (customer != null) {
             return new ResponseEntity<>(customer, HttpStatus.OK);
         } else {
             return new ResponseEntity<>(HttpStatus.NOT_FOUND);
         }
     }

     @DeleteMapping("/{id}")
     public ResponseEntity<Void> deleteCustomer(@PathVariable int id) {
         customerService.deleteCustomer(id);
         return new ResponseEntity<>(HttpStatus.NO_CONTENT);
     }
 }
