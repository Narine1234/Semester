package com.example.demo.Service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Model;
import com.example.demo.Repo.Repo;

@Service
public class serv {

    @Autowired
    Repo customerRepo;

    public Model createCustomer(Model customer) {
        return customerRepo.save(customer);
    }

    public List<Model> getAllCustomers() {
        return customerRepo.findAll();
    }

    public Page<Model> getAllCustomersWithPagination(int page, int size) {
        return customerRepo.findAll(PageRequest.of(page, size));
    }

    public Page<Model> getAllCustomersWithPaginationAndSorting(int page, int size, String sortBy) {
        return customerRepo.findAll(PageRequest.of(page, size, Sort.by(sortBy)));
    }

    public Model getCustomerById(int id) {
        return customerRepo.findById(id).orElse(null);
    }

    public Model updateCustomer(int id, Model updatedCustomer) {
        Model existingCustomer = customerRepo.findById(id).orElse(null);
        if (existingCustomer != null) {
            return customerRepo.save(existingCustomer);
        }
        return null;
    }

    public void deleteCustomer(int id) {
        customerRepo.deleteById(id);
    }
}
