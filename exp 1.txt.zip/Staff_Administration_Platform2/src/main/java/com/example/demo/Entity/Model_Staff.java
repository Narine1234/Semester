package com.example.demo.Entity;





import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue; import jakarta.persistence.GenerationType; import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity 
@Table(name="Staff_detils") 
public class Model_Staff {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY) private int emp_id;
private String name; private String department; private Long Salary; public int getEmp_id() {
return emp_id;
}
public void setEmp_id(int emp_id) { this.emp_id = emp_id;
}
public String getName() {
return name;
}
public void setName(String name) { this.name = name;
}
public String getDepartment() { return department;
}
public void setDepartment(String department) { this.department = department;
}
public Long getSalary() {
return Salary;
}
public void setSalary(Long salary) { 
	Salary = salary;
}

}
 

