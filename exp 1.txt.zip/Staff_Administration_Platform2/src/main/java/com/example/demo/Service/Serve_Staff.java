package com.example.demo.Service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired; import org.springframework.stereotype.Service;

import com.example.demo.Entity.Model_Staff;
import com.example.demo.Repo.Repo_Admin;
@Service
public class Serve_Staff {
@Autowired Repo_Admin r;

public void add(Model_Staff m)
{
r.save(m);
}
public List<Model_Staff>get_all(){ return r.findAll();
}

public void delete(int id) {
r.deleteById(id);
}

public String update_user(Model_Staff m){ r.save(m);
return "Sucess";
}
}

