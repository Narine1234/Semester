package com.example.demo.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.Model_Staff;

public interface Repo_Admin extends JpaRepository<Model_Staff, Integer> {

}
