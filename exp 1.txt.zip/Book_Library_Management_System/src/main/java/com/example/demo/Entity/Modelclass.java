package com.example.demo.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue; import jakarta.persistence.GenerationType; import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity @Table(name="New") public class Modelclass {
@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
private int id; private String title;
private String author; private int isbn;
private int publishedYear; private String genre; public int getId() {
return id;
}
public void setId(int id) {
this.id = id;
}
public String getTitle() {
return title;
}
public void setTitle(String title) { this.title = title;
 
}
public String getAuthor() {
return author;
}
public void setAuthor(String author) { this.author = author;
}
public int getIsbn() {
return isbn;
}
public void setIsbn(int isbn) { this.isbn = isbn;
}
public int getPublishedYear() { return publishedYear;
}
public void setPublishedYear(int publishedYear) { this.publishedYear = publishedYear;
}
public String getGenre() {
return genre;
}
public void setGenre(String genre) { this.genre = genre;
}
}
