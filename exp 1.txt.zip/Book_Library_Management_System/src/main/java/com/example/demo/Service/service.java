package com.example.demo.Service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Modelclass;
import com.example.demo.Repository.Repo;

@Service
public class service {
@Autowired Repo r;
public String add(Modelclass m) { r.save(m);
return "Added";
}
public List<Modelclass> getall(){ return r.findAll();
}

public void update(int id, Modelclass model) { if (r.existsById(id)) {
model.setId(id); r.save(model);
}
}

public void delete(int id) { r.deleteById(id);
}
}
 
