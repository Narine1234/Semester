package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired; import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Model;
import com.example.demo.Repo.Repo;

@Service
public class service {
@Autowired
public Repo r;
public List<Model> getall() { return r.findAll();
}
public String add(Model m) { r.save(m);
return "Added";
}
public List<Model> findid(int searchid){ return r.find(searchid);
}
public ResponseEntity<Model> updateuser( Model m) {
 
r.save(m);
return ResponseEntity.ok(m);
}
public String delete(int id){
r.deleteById(id);
return "Successfully deleted";
}
}
