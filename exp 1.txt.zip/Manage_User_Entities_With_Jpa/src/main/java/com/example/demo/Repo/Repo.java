package com.example.demo.Repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository; import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.Entity.Model;

@Repository
public interface Repo extends JpaRepository<Model,Integer>{ @Query("select e from Model e where e.id = :searchid") List<Model> find(int searchid);
}

