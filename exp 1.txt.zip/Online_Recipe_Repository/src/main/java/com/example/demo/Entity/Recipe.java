package com.example.demo.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue; import jakarta.persistence.GenerationType; import jakarta.persistence.Id;
import java.util.Date;

@Entity
public class Recipe { @Id
@GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
private String name; private String chef;
private Date yearOfCreation; private String cuisineType;

public Recipe() {
}

public Recipe(String name, String chef, Date yearOfCreation, String cuisineType) { this.name = name;
this.chef = chef;
this.yearOfCreation = yearOfCreation; this.cuisineType = cuisineType;
}

public Long getId() { return id;
}
 
public void setId(Long id) { this.id = id;
}

public String getName() { return name;
}

public void setName(String name) { this.name = name;
}

public String getChef() { return chef;
}

public void setChef(String chef) { this.chef = chef;
}

public Date getYearOfCreation() { return yearOfCreation;
}

public void setYearOfCreation(Date yearOfCreation) { this.yearOfCreation = yearOfCreation;
}

public String getCuisineType() { return cuisineType;
}

public void setCuisineType(String cuisineType) { this.cuisineType = cuisineType;
}
}

