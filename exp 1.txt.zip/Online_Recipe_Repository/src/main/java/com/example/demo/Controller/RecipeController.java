package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired; import org.springframework.web.bind.annotation.*;

import com.example.demo.Entity.Recipe;
import com.example.demo.Repository.RecipeRepository;

 import java.util.Optional;

@RestController @RequestMapping("/recipes") public class RecipeController {
@Autowired
private RecipeRepository recipeRepository;

@PostMapping("/post")
public Recipe addRecipe(@RequestBody Recipe recipe) { return recipeRepository.save(recipe);
 
}


@GetMapping("/{id}")
public Optional<Recipe> getRecipeById(@PathVariable Long id) { return recipeRepository.findById(id);
}

@PutMapping("/{id}")
public Recipe updateRecipe(@PathVariable Long id, @RequestBody Recipe updatedRecipe) { updatedRecipe.setId(id); // Ensure ID consistency
return recipeRepository.save(updatedRecipe);
}

@DeleteMapping("/{id}")
public String deleteRecipe(@PathVariable Long id) { recipeRepository.deleteById(id);
return "Value Deleted" ;
}
}
