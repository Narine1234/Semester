package com.example.demo.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue; import jakarta.persistence.GenerationType; import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity @Table(name="Staff_Auth") public class Model_Auth {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY) private int id;
private String user; private String pass; public int getId() {
return id;
}
public void setId(int id) {
this.id = id;
}
public String getUser() {
return user;
}
public void setUser(String user) { this.user = user;
}
public String getPass() {
return pass;
}
public void setPass(String pass) { this.pass= pass;
}
}

