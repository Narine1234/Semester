package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired; import org.springframework.stereotype.Service;

import com.example.demo.Entity.Model_Auth;
import com.example.demo.Repo.Repo_Auth;

@Service
public class Serve_Auth {
@Autowired Repo_Auth r;

public void add(Model_Auth m)
{
r.save(m);
}
public String get_By(String user_name,String password) { Model_Auth a=r.get_By(user_name);
if(a==null) {
return "user_name does not match";
}
else if(a.getPass().equals(password)) { return "Login";
 
}
else {
	return "Password is wrong";

}
}
 


 

}
 

