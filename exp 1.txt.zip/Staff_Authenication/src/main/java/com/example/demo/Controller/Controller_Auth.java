package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired; import org.springframework.web.bind.annotation.GetMapping; import org.springframework.web.bind.annotation.PathVariable; import org.springframework.web.bind.annotation.PostMapping; import org.springframework.web.bind.annotation.RequestBody; import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Model_Auth;
import com.example.demo.Service.Serve_Auth;

import jakarta.transaction.Transactional;


@RestController
public class Controller_Auth { @Autowired Serve_Auth s;

@PostMapping("/register")
public String create(@RequestBody Model_Auth m) { s.add(m);
return "created sucessfully";
}
@Transactional @GetMapping("/get/{user_name}/{password}")
public String get_By(@PathVariable String user_name,@PathVariable String password ) { return s.get_By(user_name,password);
 
}
}
