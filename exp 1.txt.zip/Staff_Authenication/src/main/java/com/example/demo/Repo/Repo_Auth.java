package com.example.demo.Repo;

import org.springframework.data.jpa.repository.JpaRepository; import org.springframework.data.jpa.repository.Query;

import com.example.demo.Entity.Model_Auth;

public interface Repo_Auth extends JpaRepository<Model_Auth,Integer>{
 
@Query("Select m from Model_Auth m Where m.user = :user_name") public Model_Auth get_By(String user_name);
}


