package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired; import org.springframework.web.bind.annotation.*;

import com.example.demo.Entity.Vehicle;
import com.example.demo.Service.VehicleService;

import java.util.List;

@RestController @RequestMapping("/vehicles") @CrossOrigin(origins = "http://localhost:3000") public class VehicleController {

@Autowired
private VehicleService vehicleService;

@GetMapping
public List<Vehicle> getAllVehicles() { return vehicleService.getAllVehicles();
}

@GetMapping("/{id}")
public Vehicle getVehicleById(@PathVariable Long id) { return vehicleService.getVehicleById(id);
}

@PostMapping
public Vehicle saveVehicle(@RequestBody Vehicle vehicle) { return vehicleService.saveVehicle(vehicle);
}

@PutMapping("/{id}")
public Vehicle updateVehicle(@PathVariable Long id, @RequestBody Vehicle updatedVehicle) { return vehicleService.updateVehicle(id, updatedVehicle);
}

@DeleteMapping("/{id}")
public void deleteVehicleById(@PathVariable Long id) { vehicleService.deleteVehicleById(id);
}
}

