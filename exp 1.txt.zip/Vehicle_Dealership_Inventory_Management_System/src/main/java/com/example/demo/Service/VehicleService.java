package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired; import org.springframework.stereotype.Service;

import com.example.demo.Entity.Vehicle;
import com.example.demo.Repo.VehicleRepository;

import java.util.List;
 
import java.util.Optional;

@Service
public class VehicleService { @Autowired
private VehicleRepository vehicleRepository;

public List<Vehicle> getAllVehicles() { return vehicleRepository.findAll();
}

public Vehicle saveVehicle(Vehicle vehicle) { return vehicleRepository.save(vehicle);
}

public Vehicle getVehicleById(Long id) {
return vehicleRepository.findById(id).orElse(null);
}

public void deleteVehicleById(Long id) { vehicleRepository.deleteById(id);
}
public Vehicle updateVehicle(Long id, Vehicle updatedVehicle) { Optional<Vehicle> optionalVehicle = vehicleRepository.findById(id); if (optionalVehicle.isPresent()) {
Vehicle existingVehicle = optionalVehicle.get(); existingVehicle.setMake(updatedVehicle.getMake()); existingVehicle.setModel(updatedVehicle.getModel()); existingVehicle.setColor(updatedVehicle.getColor()); existingVehicle.setVin(updatedVehicle.getVin()); existingVehicle.setYearOfManufacture(updatedVehicle.getYearOfManufacture()); return vehicleRepository.save(existingVehicle);
} else {
return null; // Or throw an exception, depending on your error handling strategy
}
}
}
