package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired; import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service; import java.util.List;
@Service
public class Serv { @Autowired private Repo repo;

public List<Model> get_all() { return repo.findAll();
}

public ResponseEntity<Model> create(Model m) { repo.save(m);
return ResponseEntity.ok(m);
}

public Model get(Integer id) {
return repo.findById(id).orElse(null);
}

public String delete(Integer id) { repo.deleteById(id);
return "deleted successfully";
}

public ResponseEntity<Model> update(Model m, Integer id) { m.setId(id);
repo.save(m);
return ResponseEntity.ok(m);
}
}
